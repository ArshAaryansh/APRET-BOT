import sqlite3
from pathlib import Path


DATABASE_PATH = Path("database/apret.db")


def get_connection():
    DATABASE_PATH.parent.mkdir(parents=True, exist_ok=True)

    connection = sqlite3.connect(DATABASE_PATH)
    connection.row_factory = sqlite3.Row

    return connection


def initialize_database():
    connection = get_connection()

    # =========================================================
    # USERS / LEVELING
    # =========================================================

    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            xp INTEGER NOT NULL DEFAULT 0,
            level INTEGER NOT NULL DEFAULT 0
        )
        """
    )

    # =========================================================
    # WARNINGS
    # =========================================================

    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS warnings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            moderator_id INTEGER NOT NULL,
            reason TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """
    )

    # =========================================================
    # GUILD SETTINGS
    # =========================================================

    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS guild_settings (
            guild_id INTEGER PRIMARY KEY
        )
        """
    )

    # =========================================================
    # DATABASE MIGRATION
    # Add new columns to existing databases.
    # =========================================================

    columns = connection.execute(
        "PRAGMA table_info(guild_settings)"
    ).fetchall()

    existing_columns = {
        column["name"]
        for column in columns
    }

    migrations = {
        "welcome_channel_id": (
            "ALTER TABLE guild_settings "
            "ADD COLUMN welcome_channel_id INTEGER"
        ),
        "leave_channel_id": (
            "ALTER TABLE guild_settings "
            "ADD COLUMN leave_channel_id INTEGER"
        ),
        "welcome_enabled": (
            "ALTER TABLE guild_settings "
            "ADD COLUMN welcome_enabled INTEGER NOT NULL DEFAULT 0"
        ),
        "leave_enabled": (
            "ALTER TABLE guild_settings "
            "ADD COLUMN leave_enabled INTEGER NOT NULL DEFAULT 0"
        ),
    }

    for column_name, sql in migrations.items():
        if column_name not in existing_columns:
            connection.execute(sql)
            print(f"Database migration: added {column_name}")

    connection.commit()
    connection.close()

    print("Database initialized successfully.")