import os

import discord
from discord.ext import commands
from dotenv import load_dotenv

from database.database import initialize_database


load_dotenv()

TOKEN = os.getenv("DISCORD_TOKEN")

if not TOKEN:
    raise RuntimeError("DISCORD_TOKEN is not set in the .env file.")


intents = discord.Intents.default()
intents.presences = True
intents.members = True
intents.message_content = True


class APRETBot(commands.Bot):
    def __init__(self):
        super().__init__(
            command_prefix="!",
            intents=intents,
        )

    async def setup_hook(self):
        # Load all Cogs
        for extension in (
            "cogs.core.core",
            "cogs.moderation.moderation",
            "cogs.community.community",
            "cogs.community.leveling",
            "cogs.community.welcome",
            "cogs.community.tickets",
            "cogs.community.giveaways",
            "cogs.minecraft.minecraft",
        ):
            try:
                await self.load_extension(extension)
                print(f"Loaded: {extension}")
            except Exception as e:
                print(f"Failed to load {extension}: {e}")

        # Sync slash commands
        guild = discord.Object(id=1194657298858127441)

        # Sync commands specifically to APRET MC
        self.tree.copy_global_to(guild=guild)
        synced = await self.tree.sync(guild=guild)

        # Remove old global commands
        self.tree.clear_commands(guild=None)
        await self.tree.sync()

        print(f"Synced {len(synced)} slash command(s) to APRET MC.")


bot = APRETBot()

initialize_database()


@bot.event
async def on_ready():
    print(f"Logged in as {bot.user} (ID: {bot.user.id})")
    print(f"Connected to {len(bot.guilds)} server(s).")


@bot.tree.command(name="ping", description="Check the bot's latency.")
async def ping(interaction: discord.Interaction):
    latency = round(bot.latency * 1000)
    await interaction.response.send_message(
        f"🏓 Pong! `{latency}ms`"
    )


bot.run(TOKEN)