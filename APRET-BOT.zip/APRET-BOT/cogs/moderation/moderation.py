import re
import time
from collections import defaultdict, deque
from datetime import timedelta

import discord
from discord import app_commands
from discord.ext import commands

from database.database import get_connection


# ============================================================
# CONFIGURATION
# ============================================================

STAFF_ROLE_NAME = "aarsh_07"
MOD_LOG_CHANNEL_NAME = "📇・server-logs"

# AutoMod settings
SPAM_MESSAGE_LIMIT = 5
SPAM_TIME_WINDOW = 7

REPEATED_MESSAGE_LIMIT = 3

MENTION_LIMIT = 5

MAX_STRIKES = 3
STRIKE_RESET_TIME = 600  # 10 minutes

AUTO_TIMEOUT_MINUTES = 10


# ============================================================
# DATABASE
# ============================================================

def initialize_moderation_database():
    connection = get_connection()

    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS automod_settings (
            guild_id INTEGER PRIMARY KEY,
            spam_enabled INTEGER NOT NULL DEFAULT 1,
            links_enabled INTEGER NOT NULL DEFAULT 1,
            mentions_enabled INTEGER NOT NULL DEFAULT 1
        )
        """
    )

    connection.commit()
    connection.close()


def get_automod_settings(guild_id):
    connection = get_connection()

    settings = connection.execute(
        """
        SELECT spam_enabled, links_enabled, mentions_enabled
        FROM automod_settings
        WHERE guild_id = ?
        """,
        (guild_id,)
    ).fetchone()

    if settings is None:
        connection.execute(
            """
            INSERT INTO automod_settings
            (guild_id, spam_enabled, links_enabled, mentions_enabled)
            VALUES (?, 1, 1, 1)
            """,
            (guild_id,)
        )

        connection.commit()

        settings = connection.execute(
            """
            SELECT spam_enabled, links_enabled, mentions_enabled
            FROM automod_settings
            WHERE guild_id = ?
            """,
            (guild_id,)
        ).fetchone()

    connection.close()

    return settings


def set_automod_setting(guild_id, setting, enabled):
    connection = get_connection()

    connection.execute(
        f"""
        INSERT INTO automod_settings
        (guild_id, spam_enabled, links_enabled, mentions_enabled)
        VALUES (?, 1, 1, 1)
        ON CONFLICT(guild_id)
        DO UPDATE SET {setting} = excluded.{setting}
        """,
        (guild_id,)
    )

    connection.execute(
        f"""
        UPDATE automod_settings
        SET {setting} = ?
        WHERE guild_id = ?
        """,
        (1 if enabled else 0, guild_id)
    )

    connection.commit()
    connection.close()


# ============================================================
# HELPERS
# ============================================================

def get_staff_role(guild):
    return discord.utils.get(
        guild.roles,
        name=STAFF_ROLE_NAME
    )


def is_staff_or_admin(member):
    if member.guild_permissions.administrator:
        return True

    staff_role = get_staff_role(member)

    return staff_role is not None and staff_role in member.roles


def get_log_channel(guild):
    return discord.utils.get(
        guild.text_channels,
        name=MOD_LOG_CHANNEL_NAME
    )


async def send_mod_log(
    guild,
    title,
    description,
    color=discord.Color.orange(),
    user=None,
    moderator=None,
    channel=None,
    content=None
):
    log_channel = get_log_channel(guild)

    if log_channel is None:
        return

    embed = discord.Embed(
        title=title,
        description=description,
        color=color,
        timestamp=discord.utils.utcnow()
    )

    if user is not None:
        embed.add_field(
            name="👤 User",
            value=f"{user.mention}\n`{user.id}`",
            inline=True
        )

    if moderator is not None:
        embed.add_field(
            name="🛡️ Moderator",
            value=f"{moderator.mention}\n`{moderator.id}`",
            inline=True
        )

    if channel is not None:
        embed.add_field(
            name="📍 Channel",
            value=channel.mention,
            inline=True
        )

    if content:
        content = content[:1000]

        embed.add_field(
            name="💬 Message",
            value=f"```{content}```",
            inline=False
        )

    try:
        await log_channel.send(embed=embed)
    except discord.HTTPException:
        pass


def can_moderate(bot, member):
    if member.guild.owner_id == member.id:
        return False

    if member == bot.user:
        return False

    if member.top_role >= member.guild.me.top_role:
        return False

    return True


# ============================================================
# MODERATION COG
# ============================================================

class Moderation(commands.Cog):

    def __init__(self, bot):
        self.bot = bot

        initialize_moderation_database()

        # User ID -> timestamps of recent messages
        self.message_history = defaultdict(deque)

        # User ID -> last message content
        self.last_messages = {}

        # User ID -> repeated-message count
        self.repeated_messages = defaultdict(int)

        # User ID -> strikes
        self.strikes = defaultdict(int)

        # User ID -> last violation timestamp
        self.last_violation = {}

    # ========================================================
    # AUTOMOD
    # ========================================================

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):

        if message.author.bot:
            return

        if message.guild is None:
            return

        member = message.author

        # Staff/admin bypass
        if is_staff_or_admin(member):
            return

        settings = get_automod_settings(message.guild.id)

        # ----------------------------------------------------
        # SPAM PROTECTION
        # ----------------------------------------------------

        if settings["spam_enabled"]:

            now = time.time()

            history = self.message_history[member.id]

            history.append(now)

            while history and now - history[0] > SPAM_TIME_WINDOW:
                history.popleft()

            # Too many messages too quickly
            if len(history) >= SPAM_MESSAGE_LIMIT:

                await self.handle_automod_violation(
                    message,
                    "🚨 Spam detected",
                    "Sending too many messages too quickly."
                )

                history.clear()

                return

            # Repeated identical messages
            content = message.content.strip().lower()

            if content and len(content) > 2:

                if self.last_messages.get(member.id) == content:
                    self.repeated_messages[member.id] += 1
                else:
                    self.repeated_messages[member.id] = 1

                self.last_messages[member.id] = content

                if (
                    self.repeated_messages[member.id]
                    >= REPEATED_MESSAGE_LIMIT
                ):
                    await self.handle_automod_violation(
                        message,
                        "🚨 Repeated message spam",
                        "The same message was sent repeatedly."
                    )

                    self.repeated_messages[member.id] = 0

                    return

        # ----------------------------------------------------
        # LINK PROTECTION
        # ----------------------------------------------------

        if settings["links_enabled"]:

            url_pattern = re.compile(
                r"(https?://|www\.)\S+",
                re.IGNORECASE
            )

            if url_pattern.search(message.content):

                # Allow APRET MC website/domain
                allowed_domains = (
                    "apretmc.mcsh.io",
                )

                content_lower = message.content.lower()

                contains_allowed_domain = any(
                    domain in content_lower
                    for domain in allowed_domains
                )

                if not contains_allowed_domain:

                    await self.handle_automod_violation(
                        message,
                        "🔗 Link blocked",
                        "Links are not allowed in this server."
                    )

                    return

        # ----------------------------------------------------
        # MENTION SPAM PROTECTION
        # ----------------------------------------------------

        if settings["mentions_enabled"]:

            mention_count = len(message.mentions)

            everyone_mention = (
                message.mention_everyone
            )

            if (
                mention_count >= MENTION_LIMIT
                or everyone_mention
            ):

                await self.handle_automod_violation(
                    message,
                    "📢 Mention spam detected",
                    "Too many users were mentioned in one message."
                )

                return

    # ========================================================
    # AUTOMOD VIOLATION HANDLER
    # ========================================================

    async def handle_automod_violation(
        self,
        message,
        title,
        reason
    ):

        member = message.author

        # Delete offending message
        try:
            await message.delete()
        except discord.HTTPException:
            pass

        # Add strike
        now = time.time()

        if (
            member.id in self.last_violation
            and now - self.last_violation[member.id]
            > STRIKE_RESET_TIME
        ):
            self.strikes[member.id] = 0

        self.strikes[member.id] += 1
        self.last_violation[member.id] = now

        strike_count = self.strikes[member.id]

        # ----------------------------------------------------
        # LOG
        # ----------------------------------------------------

        await send_mod_log(
            message.guild,
            title,
            reason,
            color=discord.Color.red(),
            user=member,
            channel=message.channel,
            content=message.content
        )

        # ----------------------------------------------------
        # WARNING
        # ----------------------------------------------------

        try:
            warning_message = await message.channel.send(
                f"⚠️ {member.mention} **AutoMod:** {reason}\n"
                f"Strike `{strike_count}/{MAX_STRIKES}`.",
                delete_after=5
            )
        except discord.HTTPException:
            warning_message = None

        # ----------------------------------------------------
        # AUTO TIMEOUT
        # ----------------------------------------------------

        if strike_count >= MAX_STRIKES:

            if can_moderate(self.bot, member):

                try:
                    await member.timeout(
                        timedelta(
                            minutes=AUTO_TIMEOUT_MINUTES
                        ),
                        reason="AutoMod: repeated violations"
                    )

                    await send_mod_log(
                        message.guild,
                        "⏱️ AutoMod timeout",
                        (
                            f"{member.mention} was automatically "
                            f"timed out after `{MAX_STRIKES}` violations."
                        ),
                        color=discord.Color.red(),
                        user=member
                    )

                    try:
                        await message.channel.send(
                            f"⏱️ {member.mention} has been "
                            f"**timed out for {AUTO_TIMEOUT_MINUTES} minutes** "
                            f"due to repeated AutoMod violations.",
                            delete_after=7
                        )
                    except discord.HTTPException:
                        pass

                except discord.HTTPException:
                    pass

            self.strikes[member.id] = 0

    # ========================================================
    # AUTOMOD STATUS
    # ========================================================

    @app_commands.command(
        name="automod",
        description="Show the current AutoMod settings."
    )
    @app_commands.default_permissions(manage_guild=True)
    async def automod(self, interaction: discord.Interaction):

        if not interaction.user.guild_permissions.manage_guild:
            await interaction.response.send_message(
                "❌ You need **Manage Server** permission.",
                ephemeral=True
            )
            return

        settings = get_automod_settings(
            interaction.guild.id
        )

        def status(value):
            return "🟢 Enabled" if value else "🔴 Disabled"

        embed = discord.Embed(
            title="🛡️ APRET MC AutoMod",
            description="Current automatic moderation settings.",
            color=discord.Color.blurple()
        )

        embed.add_field(
            name="🚨 Anti-Spam",
            value=status(settings["spam_enabled"]),
            inline=True
        )

        embed.add_field(
            name="🔗 Anti-Link",
            value=status(settings["links_enabled"]),
            inline=True
        )

        embed.add_field(
            name="📢 Anti-Mention Spam",
            value=status(settings["mentions_enabled"]),
            inline=True
        )

        embed.add_field(
            name="⏱️ Auto Timeout",
            value=f"`{AUTO_TIMEOUT_MINUTES} minutes` after `{MAX_STRIKES}` strikes",
            inline=False
        )

        embed.add_field(
            name="📇 Mod Logs",
            value=f"`#{MOD_LOG_CHANNEL_NAME}`",
            inline=False
        )

        embed.set_footer(
            text="APRET MC • AutoMod"
        )

        await interaction.response.send_message(
            embed=embed
        )

    # ========================================================
    # ENABLE / DISABLE COMMANDS
    # ========================================================

    @app_commands.command(
        name="antispam",
        description="Enable or disable anti-spam protection."
    )
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.describe(
        enabled="Enable or disable anti-spam."
    )
    async def antispam(
        self,
        interaction: discord.Interaction,
        enabled: bool
    ):

        if not interaction.user.guild_permissions.manage_guild:
            await interaction.response.send_message(
                "❌ You need **Manage Server** permission.",
                ephemeral=True
            )
            return

        set_automod_setting(
            interaction.guild.id,
            "spam_enabled",
            enabled
        )

        status = "enabled 🟢" if enabled else "disabled 🔴"

        await interaction.response.send_message(
            f"🚨 Anti-spam has been **{status}**."
        )

    @app_commands.command(
        name="antilink",
        description="Enable or disable link protection."
    )
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.describe(
        enabled="Enable or disable link protection."
    )
    async def antilink(
        self,
        interaction: discord.Interaction,
        enabled: bool
    ):

        if not interaction.user.guild_permissions.manage_guild:
            await interaction.response.send_message(
                "❌ You need **Manage Server** permission.",
                ephemeral=True
            )
            return

        set_automod_setting(
            interaction.guild.id,
            "links_enabled",
            enabled
        )

        status = "enabled 🟢" if enabled else "disabled 🔴"

        await interaction.response.send_message(
            f"🔗 Anti-link has been **{status}**."
        )

    @app_commands.command(
        name="antimention",
        description="Enable or disable mention spam protection."
    )
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.describe(
        enabled="Enable or disable mention protection."
    )
    async def antimention(
        self,
        interaction: discord.Interaction,
        enabled: bool
    ):

        if not interaction.user.guild_permissions.manage_guild:
            await interaction.response.send_message(
                "❌ You need **Manage Server** permission.",
                ephemeral=True
            )
            return

        set_automod_setting(
            interaction.guild.id,
            "mentions_enabled",
            enabled
        )

        status = "enabled 🟢" if enabled else "disabled 🔴"

        await interaction.response.send_message(
            f"📢 Anti-mention has been **{status}**."
        )

    # ========================================================
    # WARN
    # ========================================================

    @app_commands.command(
        name="warn",
        description="Warn a member."
    )
    @app_commands.default_permissions(manage_messages=True)
    @app_commands.describe(
        member="Member to warn.",
        reason="Reason for the warning."
    )
    async def warn(
        self,
        interaction: discord.Interaction,
        member: discord.Member,
        reason: str
    ):

        if not interaction.user.guild_permissions.manage_messages:
            await interaction.response.send_message(
                "❌ You need **Manage Messages** permission.",
                ephemeral=True
            )
            return

        if not can_moderate(self.bot, member):
            await interaction.response.send_message(
                "❌ I cannot moderate this member.",
                ephemeral=True
            )
            return

        connection = get_connection()

        connection.execute(
            """
            INSERT INTO warnings
            (user_id, moderator_id, reason)
            VALUES (?, ?, ?)
            """,
            (
                member.id,
                interaction.user.id,
                reason
            )
        )

        connection.commit()
        connection.close()

        embed = discord.Embed(
            title="⚠️ Member Warned",
            color=discord.Color.orange()
        )

        embed.add_field(
            name="👤 Member",
            value=member.mention,
            inline=True
        )

        embed.add_field(
            name="🛡️ Moderator",
            value=interaction.user.mention,
            inline=True
        )

        embed.add_field(
            name="📝 Reason",
            value=reason,
            inline=False
        )

        await interaction.response.send_message(
            embed=embed
        )

        await send_mod_log(
            interaction.guild,
            "⚠️ Member Warned",
            reason,
            color=discord.Color.orange(),
            user=member,
            moderator=interaction.user
        )

    # ========================================================
    # WARNINGS
    # ========================================================

    @app_commands.command(
        name="warnings",
        description="View a member's warnings."
    )
    @app_commands.default_permissions(manage_messages=True)
    async def warnings(
        self,
        interaction: discord.Interaction,
        member: discord.Member
    ):

        if not interaction.user.guild_permissions.manage_messages:
            await interaction.response.send_message(
                "❌ You need **Manage Messages** permission.",
                ephemeral=True
            )
            return

        connection = get_connection()

        warnings = connection.execute(
            """
            SELECT moderator_id, reason, created_at
            FROM warnings
            WHERE user_id = ?
            ORDER BY id DESC
            """,
            (member.id,)
        ).fetchall()

        connection.close()

        if not warnings:
            await interaction.response.send_message(
                f"✅ {member.mention} has no warnings."
            )
            return

        lines = []

        for index, warning in enumerate(
            warnings,
            start=1
        ):

            moderator = interaction.guild.get_member(
                warning["moderator_id"]
            )

            moderator_name = (
                moderator.display_name
                if moderator
                else f"User {warning['moderator_id']}"
            )

            lines.append(
                f"**#{index}** — {warning['reason']}\n"
                f"🛡️ `{moderator_name}` • `{warning['created_at']}`"
            )

        embed = discord.Embed(
            title=f"⚠️ Warnings • {member.display_name}",
            description="\n\n".join(lines),
            color=discord.Color.orange()
        )

        await interaction.response.send_message(
            embed=embed
        )

    # ========================================================
    # CLEAR WARNINGS
    # ========================================================

    @app_commands.command(
        name="clearwarns",
        description="Clear all warnings from a member."
    )
    @app_commands.default_permissions(manage_messages=True)
    async def clearwarns(
        self,
        interaction: discord.Interaction,
        member: discord.Member
    ):

        if not interaction.user.guild_permissions.manage_messages:
            await interaction.response.send_message(
                "❌ You need **Manage Messages** permission.",
                ephemeral=True
            )
            return

        connection = get_connection()

        connection.execute(
            "DELETE FROM warnings WHERE user_id = ?",
            (member.id,)
        )

        connection.commit()
        connection.close()

        await interaction.response.send_message(
            f"✅ Cleared all warnings for {member.mention}."
        )

        await send_mod_log(
            interaction.guild,
            "🧹 Warnings Cleared",
            f"All warnings were cleared for {member.mention}.",
            color=discord.Color.green(),
            user=member,
            moderator=interaction.user
        )

    # ========================================================
    # KICK
    # ========================================================

    @app_commands.command(
        name="kick",
        description="Kick a member."
    )
    @app_commands.default_permissions(kick_members=True)
    async def kick(
        self,
        interaction: discord.Interaction,
        member: discord.Member,
        reason: str = "No reason provided"
    ):

        if not interaction.user.guild_permissions.kick_members:
            await interaction.response.send_message(
                "❌ You need **Kick Members** permission.",
                ephemeral=True
            )
            return

        if not can_moderate(self.bot, member):
            await interaction.response.send_message(
                "❌ I cannot kick this member.",
                ephemeral=True
            )
            return

        try:
            await member.kick(reason=reason)

            await interaction.response.send_message(
                f"👢 Kicked {member.mention}.\n"
                f"**Reason:** {reason}"
            )

            await send_mod_log(
                interaction.guild,
                "👢 Member Kicked",
                reason,
                color=discord.Color.red(),
                user=member,
                moderator=interaction.user
            )

        except discord.HTTPException:
            await interaction.response.send_message(
                "❌ Failed to kick the member.",
                ephemeral=True
            )

    # ========================================================
    # BAN
    # ========================================================

    @app_commands.command(
        name="ban",
        description="Ban a member."
    )
    @app_commands.default_permissions(ban_members=True)
    async def ban(
        self,
        interaction: discord.Interaction,
        member: discord.Member,
        reason: str = "No reason provided"
    ):

        if not interaction.user.guild_permissions.ban_members:
            await interaction.response.send_message(
                "❌ You need **Ban Members** permission.",
                ephemeral=True
            )
            return

        if not can_moderate(self.bot, member):
            await interaction.response.send_message(
                "❌ I cannot ban this member.",
                ephemeral=True
            )
            return

        try:
            await member.ban(
                reason=reason
            )

            await interaction.response.send_message(
                f"🔨 Banned {member.mention}.\n"
                f"**Reason:** {reason}"
            )

            await send_mod_log(
                interaction.guild,
                "🔨 Member Banned",
                reason,
                color=discord.Color.red(),
                user=member,
                moderator=interaction.user
            )

        except discord.HTTPException:
            await interaction.response.send_message(
                "❌ Failed to ban the member.",
                ephemeral=True
            )

    # ========================================================
    # UNBAN
    # ========================================================

    @app_commands.command(
        name="unban",
        description="Unban a user by ID."
    )
    @app_commands.default_permissions(ban_members=True)
    async def unban(
        self,
        interaction: discord.Interaction,
        user_id: str
    ):

        if not interaction.user.guild_permissions.ban_members:
            await interaction.response.send_message(
                "❌ You need **Ban Members** permission.",
                ephemeral=True
            )
            return

        try:
            user = await self.bot.fetch_user(
                int(user_id)
            )
        except (ValueError, discord.NotFound):
            await interaction.response.send_message(
                "❌ Invalid user ID.",
                ephemeral=True
            )
            return

        try:
            await interaction.guild.unban(
                user
            )

            await interaction.response.send_message(
                f"✅ Unbanned **{user}**."
            )

            await send_mod_log(
                interaction.guild,
                "✅ Member Unbanned",
                f"{user.mention} was unbanned.",
                color=discord.Color.green(),
                user=user,
                moderator=interaction.user
            )

        except discord.NotFound:
            await interaction.response.send_message(
                "❌ That user is not banned.",
                ephemeral=True
            )

    # ========================================================
    # TIMEOUT
    # ========================================================

    @app_commands.command(
        name="timeout",
        description="Timeout a member."
    )
    @app_commands.default_permissions(moderate_members=True)
    async def timeout(
        self,
        interaction: discord.Interaction,
        member: discord.Member,
        minutes: int,
        reason: str = "No reason provided"
    ):

        if not interaction.user.guild_permissions.moderate_members:
            await interaction.response.send_message(
                "❌ You need **Moderate Members** permission.",
                ephemeral=True
            )
            return

        if minutes < 1 or minutes > 40320:
            await interaction.response.send_message(
                "❌ Timeout must be between 1 minute and 28 days.",
                ephemeral=True
            )
            return

        if not can_moderate(self.bot, member):
            await interaction.response.send_message(
                "❌ I cannot timeout this member.",
                ephemeral=True
            )
            return

        try:
            await member.timeout(
                timedelta(minutes=minutes),
                reason=reason
            )

            await interaction.response.send_message(
                f"⏱️ Timed out {member.mention} "
                f"for **{minutes} minutes**.\n"
                f"**Reason:** {reason}"
            )

            await send_mod_log(
                interaction.guild,
                "⏱️ Member Timed Out",
                reason,
                color=discord.Color.orange(),
                user=member,
                moderator=interaction.user
            )

        except discord.HTTPException:
            await interaction.response.send_message(
                "❌ Failed to timeout the member.",
                ephemeral=True
            )

    # ========================================================
    # UNTIMEOUT
    # ========================================================

    @app_commands.command(
        name="untimeout",
        description="Remove a member's timeout."
    )
    @app_commands.default_permissions(moderate_members=True)
    async def untimeout(
        self,
        interaction: discord.Interaction,
        member: discord.Member
    ):

        if not interaction.user.guild_permissions.moderate_members:
            await interaction.response.send_message(
                "❌ You need **Moderate Members** permission.",
                ephemeral=True
            )
            return

        try:
            await member.timeout(
                None,
                reason=f"Timeout removed by {interaction.user}"
            )

            await interaction.response.send_message(
                f"✅ Removed timeout from {member.mention}."
            )

            await send_mod_log(
                interaction.guild,
                "✅ Timeout Removed",
                f"Timeout removed from {member.mention}.",
                color=discord.Color.green(),
                user=member,
                moderator=interaction.user
            )

        except discord.HTTPException:
            await interaction.response.send_message(
                "❌ Failed to remove the timeout.",
                ephemeral=True
            )

    # ========================================================
    # PURGE
    # ========================================================

    @app_commands.command(
        name="purge",
        description="Delete multiple messages."
    )
    @app_commands.default_permissions(manage_messages=True)
    async def purge(
        self,
        interaction: discord.Interaction,
        amount: int
    ):

        if not interaction.user.guild_permissions.manage_messages:
            await interaction.response.send_message(
                "❌ You need **Manage Messages** permission.",
                ephemeral=True
            )
            return

        if amount < 1 or amount > 100:
            await interaction.response.send_message(
                "❌ Amount must be between 1 and 100.",
                ephemeral=True
            )
            return

        await interaction.response.defer(
            ephemeral=True
        )

        try:
            deleted = await interaction.channel.purge(
                limit=amount
            )

            await interaction.followup.send(
                f"🧹 Deleted **{len(deleted)} messages**."
            )

            await send_mod_log(
                interaction.guild,
                "🧹 Messages Purged",
                f"Deleted `{len(deleted)}` messages.",
                color=discord.Color.orange(),
                moderator=interaction.user,
                channel=interaction.channel
            )

        except discord.HTTPException:
            await interaction.followup.send(
                "❌ Failed to purge messages."
            )


# ============================================================
# SETUP
# ============================================================

async def setup(bot: commands.Bot):
    await bot.add_cog(Moderation(bot))