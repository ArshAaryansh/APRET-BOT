import discord
from discord.ext import commands


class Core(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @discord.app_commands.command(
        name="botinfo",
        description="Show information about the APRET bot."
    )
    async def botinfo(self, interaction: discord.Interaction):
        embed = discord.Embed(
            title="🤖 APRET Bot",
            description="All-in-one bot for APRET MC.",
            color=discord.Color.blurple()
        )

        embed.add_field(
            name="Servers",
            value=str(len(self.bot.guilds)),
            inline=True
        )

        embed.add_field(
            name="Latency",
            value=f"{round(self.bot.latency * 1000)}ms",
            inline=True
        )

        embed.set_footer(text="APRET MC")

        await interaction.response.send_message(embed=embed)


async def setup(bot: commands.Bot):
    await bot.add_cog(Core(bot))