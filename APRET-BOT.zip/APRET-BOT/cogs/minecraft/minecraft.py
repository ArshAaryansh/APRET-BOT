import discord
from discord import app_commands
from discord.ext import commands
from mcstatus import JavaServer


# ============================================================
# APRET MC SERVER CONFIG
# ============================================================

SERVER_IP = "144.31.46.13"
SERVER_PORT = 12948

DISPLAY_IP = "apretmc.mcsh.io"
DISPLAY_VERSION = "26.2"


# ============================================================
# MINECRAFT COG
# ============================================================

class Minecraft(commands.Cog):

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    # --------------------------------------------------------
    # /server
    # --------------------------------------------------------

    @app_commands.command(
        name="server",
        description="Show the current APRET MC server status."
    )
    async def server(
        self,
        interaction: discord.Interaction
    ):
        await interaction.response.defer()

        try:
            server = JavaServer(
                SERVER_IP,
                SERVER_PORT
            )

            status = await server.async_status()

            online = True
            players_online = status.players.online
            players_max = status.players.max

        except Exception:
            online = False
            players_online = 0
            players_max = 0

        # ----------------------------------------------------
        # ONLINE
        # ----------------------------------------------------

        if online:
            status_text = "🟢 **ONLINE**"
            status_color = discord.Color.green()

        # ----------------------------------------------------
        # OFFLINE
        # ----------------------------------------------------

        else:
            status_text = "🔴 **OFFLINE**"
            status_color = discord.Color.red()

        # ----------------------------------------------------
        # EMBED
        # ----------------------------------------------------

        embed = discord.Embed(
            title="⛏️ APRET MC",
            color=status_color
        )

        embed.add_field(
            name="🌐 IP",
            value=f"`{DISPLAY_IP}`",
            inline=False
        )

        embed.add_field(
            name="📡 Status",
            value=status_text,
            inline=True
        )

        embed.add_field(
            name="👥 Players",
            value=f"`{players_online} / {players_max}`",
            inline=True
        )

        embed.add_field(
            name="🧩 Version",
            value=f"`{DISPLAY_VERSION}`",
            inline=True
        )

        embed.set_footer(
            text="APRET MC • Live Server Status"
        )

        await interaction.followup.send(
            embed=embed
        )


# ============================================================
# SETUP
# ============================================================

async def setup(bot: commands.Bot):
    await bot.add_cog(Minecraft(bot))