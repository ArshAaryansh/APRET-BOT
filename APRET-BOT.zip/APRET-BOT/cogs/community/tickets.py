import io
from datetime import datetime

import discord
from discord import app_commands
from discord.ext import commands

from database.database import get_connection


# ============================================================
# CONFIG
# ============================================================

STAFF_ROLE_NAME = "aarsh_07"
TICKET_PING_ROLE_NAME = "ticket-ping"
TICKET_CATEGORY_NAME = "🎫 TICKETS"


TICKET_TYPES = {
    "staff": {
        "name": "Staff Application",
        "emoji": "🛡️",
        "prefix": "staff-",
        "description": "Apply to become a member of the APRET MC staff team."
    },
    "general": {
        "name": "General Support",
        "emoji": "💬",
        "prefix": "general-",
        "description": "Get help with APRET MC or ask a general question."
    },
    "partnership": {
        "name": "Partnership",
        "emoji": "🤝",
        "prefix": "partnership-",
        "description": "Contact the APRET MC team regarding partnerships."
    }
}


# ============================================================
# DATABASE
# ============================================================

def initialize_ticket_database():
    connection = get_connection()

    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS tickets (
            channel_id INTEGER PRIMARY KEY,
            guild_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            ticket_type TEXT NOT NULL,
            claimed_by INTEGER,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            closed_at TIMESTAMP
        )
        """
    )

    connection.commit()
    connection.close()


# ============================================================
# HELPERS
# ============================================================

def get_role(guild: discord.Guild, role_name: str):
    return discord.utils.find(
        lambda role: role.name == role_name,
        guild.roles
    )


def get_ticket(channel_id: int):
    connection = get_connection()

    ticket = connection.execute(
        """
        SELECT *
        FROM tickets
        WHERE channel_id = ?
        """,
        (channel_id,)
    ).fetchone()

    connection.close()

    return ticket


def get_user_ticket(guild_id: int, user_id: int):
    connection = get_connection()

    ticket = connection.execute(
        """
        SELECT *
        FROM tickets
        WHERE guild_id = ?
        AND user_id = ?
        AND closed_at IS NULL
        """,
        (guild_id, user_id)
    ).fetchone()

    connection.close()

    return ticket


def save_ticket(
    channel_id: int,
    guild_id: int,
    user_id: int,
    ticket_type: str
):
    connection = get_connection()

    connection.execute(
        """
        INSERT INTO tickets (
            channel_id,
            guild_id,
            user_id,
            ticket_type
        )
        VALUES (?, ?, ?, ?)
        """,
        (
            channel_id,
            guild_id,
            user_id,
            ticket_type
        )
    )

    connection.commit()
    connection.close()


def update_claim(channel_id: int, user_id):
    connection = get_connection()

    connection.execute(
        """
        UPDATE tickets
        SET claimed_by = ?
        WHERE channel_id = ?
        """,
        (user_id, channel_id)
    )

    connection.commit()
    connection.close()


def close_ticket_database(channel_id: int):
    connection = get_connection()

    connection.execute(
        """
        UPDATE tickets
        SET closed_at = CURRENT_TIMESTAMP
        WHERE channel_id = ?
        """,
        (channel_id,)
    )

    connection.commit()
    connection.close()


def delete_ticket_database(channel_id: int):
    connection = get_connection()

    connection.execute(
        """
        DELETE FROM tickets
        WHERE channel_id = ?
        """,
        (channel_id,)
    )

    connection.commit()
    connection.close()


# ============================================================
# TICKET PANEL
# ============================================================

class TicketPanel(discord.ui.View):

    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(
        label="Staff Application",
        emoji="🛡️",
        style=discord.ButtonStyle.primary,
        custom_id="ticket_staff"
    )
    async def staff_ticket(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button
    ):
        await create_ticket(interaction, "staff")

    @discord.ui.button(
        label="General Support",
        emoji="💬",
        style=discord.ButtonStyle.success,
        custom_id="ticket_general"
    )
    async def general_ticket(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button
    ):
        await create_ticket(interaction, "general")

    @discord.ui.button(
        label="Partnership",
        emoji="🤝",
        style=discord.ButtonStyle.secondary,
        custom_id="ticket_partnership"
    )
    async def partnership_ticket(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button
    ):
        await create_ticket(interaction, "partnership")


# ============================================================
# TICKET MANAGEMENT VIEW
# ============================================================

class TicketControls(discord.ui.View):

    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(
        label="Claim",
        emoji="🙋",
        style=discord.ButtonStyle.primary,
        custom_id="ticket_claim"
    )
    async def claim(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button
    ):
        ticket = get_ticket(interaction.channel.id)

        if ticket is None:
            await interaction.response.send_message(
                "❌ This is not a ticket channel.",
                ephemeral=True
            )
            return

        staff_role = get_role(
            interaction.guild,
            STAFF_ROLE_NAME
        )

        if staff_role not in interaction.user.roles:
            await interaction.response.send_message(
                "❌ Only staff members can claim tickets.",
                ephemeral=True
            )
            return

        if ticket["claimed_by"] is not None:
            claimed_user = interaction.guild.get_member(
                ticket["claimed_by"]
            )

            name = (
                claimed_user.mention
                if claimed_user
                else "another staff member"
            )

            await interaction.response.send_message(
                f"⚠️ This ticket is already claimed by {name}.",
                ephemeral=True
            )
            return

        update_claim(
            interaction.channel.id,
            interaction.user.id
        )

        await interaction.response.send_message(
            f"🙋 **Ticket claimed by {interaction.user.mention}!**"
        )

    @discord.ui.button(
        label="Unclaim",
        emoji="↩️",
        style=discord.ButtonStyle.secondary,
        custom_id="ticket_unclaim"
    )
    async def unclaim(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button
    ):
        ticket = get_ticket(interaction.channel.id)

        if ticket is None:
            await interaction.response.send_message(
                "❌ This is not a ticket channel.",
                ephemeral=True
            )
            return

        staff_role = get_role(
            interaction.guild,
            STAFF_ROLE_NAME
        )

        if staff_role not in interaction.user.roles:
            await interaction.response.send_message(
                "❌ Only staff members can unclaim tickets.",
                ephemeral=True
            )
            return

        if ticket["claimed_by"] is None:
            await interaction.response.send_message(
                "⚠️ This ticket is not currently claimed.",
                ephemeral=True
            )
            return

        if (
            ticket["claimed_by"] != interaction.user.id
            and not interaction.user.guild_permissions.administrator
        ):
            await interaction.response.send_message(
                "❌ Only the staff member who claimed this ticket "
                "or an administrator can unclaim it.",
                ephemeral=True
            )
            return

        update_claim(
            interaction.channel.id,
            None
        )

        await interaction.response.send_message(
            f"↩️ {interaction.user.mention} unclaimed this ticket."
        )

    @discord.ui.button(
        label="Close",
        emoji="🔒",
        style=discord.ButtonStyle.danger,
        custom_id="ticket_close"
    )
    async def close(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button
    ):
        ticket = get_ticket(interaction.channel.id)

        if ticket is None:
            await interaction.response.send_message(
                "❌ This is not a ticket channel.",
                ephemeral=True
            )
            return

        staff_role = get_role(
            interaction.guild,
            STAFF_ROLE_NAME
        )

        is_staff = (
            staff_role in interaction.user.roles
            if staff_role
            else False
        )

        is_owner = ticket["user_id"] == interaction.user.id

        if not is_staff and not is_owner:
            await interaction.response.send_message(
                "❌ You cannot close this ticket.",
                ephemeral=True
            )
            return

        close_ticket_database(
            interaction.channel.id
        )

        await interaction.response.send_message(
            "🔒 **Ticket closed.**\n"
            "A staff member can delete this ticket when ready.",
            view=ClosedTicketControls()
        )


class ClosedTicketControls(discord.ui.View):

    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(
        label="Delete Ticket",
        emoji="🗑️",
        style=discord.ButtonStyle.danger,
        custom_id="ticket_delete"
    )
    async def delete(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button
    ):
        ticket = get_ticket(interaction.channel.id)

        staff_role = get_role(
            interaction.guild,
            STAFF_ROLE_NAME
        )

        is_staff = (
            staff_role in interaction.user.roles
            if staff_role
            else False
        )

        if not is_staff:
            await interaction.response.send_message(
                "❌ Only staff can delete tickets.",
                ephemeral=True
            )
            return

        await interaction.response.send_message(
            "🗑️ Deleting ticket..."
        )

        await interaction.channel.delete(
            reason=f"Ticket deleted by {interaction.user}"
        )

        if ticket:
            delete_ticket_database(
                ticket["channel_id"]
            )


# ============================================================
# CREATE TICKET
# ============================================================

async def create_ticket(
    interaction: discord.Interaction,
    ticket_type: str
):
    guild = interaction.guild
    user = interaction.user

    if guild is None:
        await interaction.response.send_message(
            "❌ Tickets can only be created inside a server.",
            ephemeral=True
        )
        return

    existing_ticket = get_user_ticket(
        guild.id,
        user.id
    )

    if existing_ticket:
        existing_channel = guild.get_channel(
            existing_ticket["channel_id"]
        )

        if existing_channel:
            await interaction.response.send_message(
                f"⚠️ You already have an open ticket: "
                f"{existing_channel.mention}",
                ephemeral=True
            )
            return

        delete_ticket_database(
            existing_ticket["channel_id"]
        )

    staff_role = get_role(
        guild,
        STAFF_ROLE_NAME
    )

    ping_role = get_role(
        guild,
        TICKET_PING_ROLE_NAME
    )

    if staff_role is None:
        await interaction.response.send_message(
            f"❌ Staff role `{STAFF_ROLE_NAME}` was not found.",
            ephemeral=True
        )
        return

    if ping_role is None:
        await interaction.response.send_message(
            f"❌ Ticket ping role `{TICKET_PING_ROLE_NAME}` "
            "was not found.",
            ephemeral=True
        )
        return

    category = discord.utils.get(
        guild.categories,
        name=TICKET_CATEGORY_NAME
    )

    if category is None:
        try:
            category = await guild.create_category(
                TICKET_CATEGORY_NAME,
                reason="Creating ticket category"
            )
        except discord.Forbidden:
            await interaction.response.send_message(
                "❌ I don't have permission to create categories.",
                ephemeral=True
            )
            return

    data = TICKET_TYPES[ticket_type]

    channel_name = (
        f"{data['prefix']}"
        f"{user.name.lower()}"
    )

    overwrites = {
        guild.default_role: discord.PermissionOverwrite(
            view_channel=False
        ),

        user: discord.PermissionOverwrite(
            view_channel=True,
            send_messages=True,
            read_message_history=True,
            attach_files=True,
            embed_links=True
        ),

        staff_role: discord.PermissionOverwrite(
            view_channel=True,
            send_messages=True,
            read_message_history=True,
            manage_messages=True,
            attach_files=True,
            embed_links=True
        ),

        guild.me: discord.PermissionOverwrite(
            view_channel=True,
            send_messages=True,
            read_message_history=True,
            manage_channels=True,
            manage_messages=True,
            attach_files=True,
            embed_links=True
        )
    }

    try:
        channel = await guild.create_text_channel(
            name=channel_name,
            category=category,
            overwrites=overwrites,
            reason=f"{data['name']} ticket created"
        )

    except discord.Forbidden:
        await interaction.response.send_message(
            "❌ I don't have permission to create ticket channels.",
            ephemeral=True
        )
        return

    save_ticket(
        channel.id,
        guild.id,
        user.id,
        ticket_type
    )

    embed = discord.Embed(
        title=(
            f"{data['emoji']} {data['name']}"
        ),
        description=(
            f"Welcome {user.mention}!\n\n"
            f"{data['description']}\n\n"
            "Please provide all the information needed "
            "so our staff team can help you."
        ),
        color=discord.Color.blurple(),
        timestamp=datetime.utcnow()
    )

    embed.add_field(
        name="👤 Created By",
        value=user.mention,
        inline=True
    )

    embed.add_field(
        name="📂 Category",
        value=data["name"],
        inline=True
    )

    embed.set_thumbnail(
        url=user.display_avatar.url
    )

    embed.set_footer(
        text="APRET MC • Ticket System"
    )

    await channel.send(
        content=ping_role.mention,
        embed=embed,
        view=TicketControls(),
        allowed_mentions=discord.AllowedMentions(
            roles=True,
            users=True
        )
    )

    await interaction.response.send_message(
        f"🎫 Your ticket has been created: {channel.mention}",
        ephemeral=True
    )


# ============================================================
# COG
# ============================================================

class Tickets(commands.Cog):

    def __init__(self, bot: commands.Bot):
        self.bot = bot

        initialize_ticket_database()

        # Persistent buttons
        self.bot.add_view(TicketPanel())
        self.bot.add_view(TicketControls())
        self.bot.add_view(ClosedTicketControls())

    # --------------------------------------------------------
    # TICKET PANEL
    # --------------------------------------------------------

    @app_commands.command(
        name="ticketpanel",
        description="Send the APRET MC ticket panel."
    )
    @app_commands.default_permissions(
        administrator=True
    )
    async def ticketpanel(
        self,
        interaction: discord.Interaction
    ):
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message(
                "❌ Administrator permission required.",
                ephemeral=True
            )
            return

        embed = discord.Embed(
            title="🎫 APRET MC Support",
            description=(
                "Need help or want to contact the APRET MC team?\n\n"
                "Choose the appropriate ticket category below.\n\n"
                "🛡️ **Staff Application**\n"
                "Apply to join the APRET MC staff team.\n\n"
                "💬 **General Support**\n"
                "Get help or ask a general question.\n\n"
                "🤝 **Partnership**\n"
                "Contact us about a partnership."
            ),
            color=discord.Color.blurple()
        )

        embed.set_footer(
            text="APRET MC • Please open only one ticket at a time."
        )

        await interaction.channel.send(
            embed=embed,
            view=TicketPanel()
        )

        await interaction.response.send_message(
            "✅ Ticket panel created!",
            ephemeral=True
        )

    # --------------------------------------------------------
    # ADD
    # --------------------------------------------------------

    @app_commands.command(
        name="add",
        description="Add a member to the current ticket."
    )
    @app_commands.describe(
        member="Member to add to the ticket."
    )
    async def add(
        self,
        interaction: discord.Interaction,
        member: discord.Member
    ):
        ticket = get_ticket(interaction.channel.id)

        if ticket is None:
            await interaction.response.send_message(
                "❌ This command can only be used inside a ticket.",
                ephemeral=True
            )
            return

        staff_role = get_role(
            interaction.guild,
            STAFF_ROLE_NAME
        )

        if staff_role not in interaction.user.roles:
            await interaction.response.send_message(
                "❌ Only staff can add members to tickets.",
                ephemeral=True
            )
            return

        await interaction.channel.set_permissions(
            member,
            view_channel=True,
            send_messages=True,
            read_message_history=True,
            attach_files=True,
            embed_links=True
        )

        await interaction.response.send_message(
            f"✅ Added {member.mention} to this ticket."
        )

    # --------------------------------------------------------
    # REMOVE
    # --------------------------------------------------------

    @app_commands.command(
        name="remove",
        description="Remove a member from the current ticket."
    )
    @app_commands.describe(
        member="Member to remove."
    )
    async def remove(
        self,
        interaction: discord.Interaction,
        member: discord.Member
    ):
        ticket = get_ticket(interaction.channel.id)

        if ticket is None:
            await interaction.response.send_message(
                "❌ This command can only be used inside a ticket.",
                ephemeral=True
            )
            return

        staff_role = get_role(
            interaction.guild,
            STAFF_ROLE_NAME
        )

        if staff_role not in interaction.user.roles:
            await interaction.response.send_message(
                "❌ Only staff can remove members.",
                ephemeral=True
            )
            return

        if member.id == ticket["user_id"]:
            await interaction.response.send_message(
                "❌ You cannot remove the ticket owner.",
                ephemeral=True
            )
            return

        await interaction.channel.set_permissions(
            member,
            overwrite=None
        )

        await interaction.response.send_message(
            f"✅ Removed {member.mention} from this ticket."
        )

    # --------------------------------------------------------
    # RENAME
    # --------------------------------------------------------

    @app_commands.command(
        name="rename",
        description="Rename the current ticket."
    )
    @app_commands.describe(
        name="New ticket name."
    )
    async def rename(
        self,
        interaction: discord.Interaction,
        name: str
    ):
        ticket = get_ticket(interaction.channel.id)

        if ticket is None:
            await interaction.response.send_message(
                "❌ This command can only be used inside a ticket.",
                ephemeral=True
            )
            return

        staff_role = get_role(
            interaction.guild,
            STAFF_ROLE_NAME
        )

        if staff_role not in interaction.user.roles:
            await interaction.response.send_message(
                "❌ Only staff can rename tickets.",
                ephemeral=True
            )
            return

        name = name.lower().replace(" ", "-")[:90]

        await interaction.channel.edit(
            name=f"🎫・{name}"
        )

        await interaction.response.send_message(
            f"✅ Ticket renamed to **{name}**."
        )

    # --------------------------------------------------------
    # TICKET INFO
    # --------------------------------------------------------

    @app_commands.command(
        name="ticketinfo",
        description="Show information about the current ticket."
    )
    async def ticketinfo(
        self,
        interaction: discord.Interaction
    ):
        ticket = get_ticket(interaction.channel.id)

        if ticket is None:
            await interaction.response.send_message(
                "❌ This command can only be used inside a ticket.",
                ephemeral=True
            )
            return

        owner = interaction.guild.get_member(
            ticket["user_id"]
        )

        ticket_data = TICKET_TYPES.get(
            ticket["ticket_type"],
            {}
        )

        claimed = "Nobody"

        if ticket["claimed_by"]:
            claimed_member = interaction.guild.get_member(
                ticket["claimed_by"]
            )

            if claimed_member:
                claimed = claimed_member.mention
            else:
                claimed = f"<@{ticket['claimed_by']}>"

        embed = discord.Embed(
            title="🎫 Ticket Information",
            color=discord.Color.blurple()
        )

        embed.add_field(
            name="👤 Owner",
            value=owner.mention if owner else "Unknown",
            inline=True
        )

        embed.add_field(
            name="📂 Type",
            value=ticket_data.get(
                "name",
                ticket["ticket_type"]
            ),
            inline=True
        )

        embed.add_field(
            name="🙋 Claimed By",
            value=claimed,
            inline=True
        )

        embed.add_field(
            name="🆔 Channel ID",
            value=str(interaction.channel.id),
            inline=False
        )

        await interaction.response.send_message(
            embed=embed,
            ephemeral=True
        )

    # --------------------------------------------------------
    # TRANSCRIPT
    # --------------------------------------------------------

    @app_commands.command(
        name="transcript",
        description="Create a transcript of the current ticket."
    )
    async def transcript(
        self,
        interaction: discord.Interaction
    ):
        ticket = get_ticket(interaction.channel.id)

        if ticket is None:
            await interaction.response.send_message(
                "❌ This command can only be used inside a ticket.",
                ephemeral=True
            )
            return

        staff_role = get_role(
            interaction.guild,
            STAFF_ROLE_NAME
        )

        if staff_role not in interaction.user.roles:
            await interaction.response.send_message(
                "❌ Only staff can create transcripts.",
                ephemeral=True
            )
            return

        await interaction.response.defer(
            ephemeral=True
        )

        messages = []

        async for message in interaction.channel.history(
            limit=None,
            oldest_first=True
        ):
            timestamp = message.created_at.strftime(
                "%Y-%m-%d %H:%M:%S"
            )

            content = message.content or "[Embed/Attachment]"

            messages.append(
                f"[{timestamp}] "
                f"{message.author} ({message.author.id}): "
                f"{content}"
            )

        transcript_text = "\n".join(messages)

        file = discord.File(
            io.BytesIO(
                transcript_text.encode("utf-8")
            ),
            filename=(
                f"transcript-{interaction.channel.name}.txt"
            )
        )

        await interaction.followup.send(
            "📄 Ticket transcript:",
            file=file,
            ephemeral=True
        )


# ============================================================
# SETUP
# ============================================================

async def setup(bot: commands.Bot):
    await bot.add_cog(Tickets(bot))