import random
import time

import discord
from discord.ext import commands

from database.database import get_connection


class Leveling(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

        # User ID -> last time they received XP
        self.xp_cooldowns = {}

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot or message.guild is None:
            return

        user_id = message.author.id
        current_time = time.time()

        # 15-second XP cooldown
        if user_id in self.xp_cooldowns:
            if current_time - self.xp_cooldowns[user_id] < 15:
                return

        self.xp_cooldowns[user_id] = current_time

        # Random XP between 5 and 10
        xp_gain = random.randint(5, 10)

        connection = get_connection()

        user = connection.execute(
            "SELECT xp, level FROM users WHERE user_id = ?",
            (user_id,)
        ).fetchone()

        if user is None:
            xp = xp_gain
            level = 0

            connection.execute(
                """
                INSERT INTO users (user_id, xp, level)
                VALUES (?, ?, ?)
                """,
                (user_id, xp, level)
            )

        else:
            xp = user["xp"] + xp_gain
            level = user["level"]

        # XP required for the next level
        required_xp = 100 + (level * 50)

        # Level up
        if xp >= required_xp:
            xp -= required_xp
            level += 1

            try:
                await message.channel.send(
                    f"🎉 {message.author.mention} "
                    f"leveled up to **Level {level}**!"
                )
            except discord.HTTPException:
                pass

        connection.execute(
            """
            UPDATE users
            SET xp = ?, level = ?
            WHERE user_id = ?
            """,
            (xp, level, user_id)
        )

        connection.commit()
        connection.close()

    @discord.app_commands.command(
        name="level",
        description="Check your current level and XP."
    )
    async def level(self, interaction: discord.Interaction):
        user_id = interaction.user.id

        connection = get_connection()

        user = connection.execute(
            "SELECT xp, level FROM users WHERE user_id = ?",
            (user_id,)
        ).fetchone()

        connection.close()

        if user is None:
            xp = 0
            level = 0
        else:
            xp = user["xp"]
            level = user["level"]

        required_xp = 100 + (level * 50)

        embed = discord.Embed(
            title="📊 Your Level",
            color=discord.Color.blurple()
        )

        embed.add_field(
            name="Level",
            value=f"**{level}**",
            inline=True
        )

        embed.add_field(
            name="XP",
            value=f"**{xp} / {required_xp}**",
            inline=True
        )

        embed.set_author(
            name=interaction.user.display_name,
            icon_url=interaction.user.display_avatar.url
        )

        embed.set_footer(
            text="APRET MC • Leveling"
        )

        await interaction.response.send_message(
            embed=embed
        )

    @discord.app_commands.command(
        name="leaderboard",
        description="Show the server's top members by level."
    )
    async def leaderboard(self, interaction: discord.Interaction):
        connection = get_connection()

        users = connection.execute(
            """
            SELECT user_id, xp, level
            FROM users
            ORDER BY level DESC, xp DESC
            LIMIT 10
            """
        ).fetchall()

        connection.close()

        if not users:
            await interaction.response.send_message(
                "📊 No one has earned XP yet!"
            )
            return

        embed = discord.Embed(
            title="🏆 APRET Level Leaderboard",
            description="Top 10 members by level and XP",
            color=discord.Color.gold()
        )

        lines = []

        medals = ["🥇", "🥈", "🥉"]

        for position, user in enumerate(users, start=1):
            member = interaction.guild.get_member(
                user["user_id"]
            )

            if member:
                name = member.display_name
            else:
                name = f"User {user['user_id']}"

            if position <= 3:
                prefix = medals[position - 1]
            else:
                prefix = f"**#{position}**"

            lines.append(
                f"{prefix} **{name}** — "
                f"Level `{user['level']}` • `{user['xp']} XP`"
            )

        embed.description = "\n".join(lines)

        embed.set_footer(
            text="APRET MC • Leveling"
        )

        await interaction.response.send_message(
            embed=embed
        )


async def setup(bot: commands.Bot):
    await bot.add_cog(Leveling(bot))