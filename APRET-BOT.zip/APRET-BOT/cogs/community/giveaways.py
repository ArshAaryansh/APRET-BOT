import random
import re
import time

import discord
from discord import app_commands
from discord.ext import commands, tasks

from database.database import get_connection


STAFF_ROLE_NAME = "aarsh_07"
LOG_CHANNEL_NAME = "📇・server-logs"


# ============================================================
# HELPERS
# ============================================================

def parse_duration(duration: str) -> int | None:
    """
    Supports:
    30s
    10m
    2h
    1d
    1h30m
    2d12h
    """

    duration = duration.lower().replace(" ", "")

    matches = re.findall(
        r"(\d+)([smhd])",
        duration
    )

    if not matches:
        return None

    multipliers = {
        "s": 1,
        "m": 60,
        "h": 3600,
        "d": 86400,
    }

    total_seconds = 0

    for amount, unit in matches:
        total_seconds += (
            int(amount) * multipliers[unit]
        )

    if total_seconds <= 0:
        return None

    return total_seconds


def format_duration(seconds: int) -> str:
    days, seconds = divmod(
        seconds,
        86400
    )

    hours, seconds = divmod(
        seconds,
        3600
    )

    minutes, seconds = divmod(
        seconds,
        60
    )

    parts = []

    if days:
        parts.append(
            f"{days}d"
        )

    if hours:
        parts.append(
            f"{hours}h"
        )

    if minutes:
        parts.append(
            f"{minutes}m"
        )

    if seconds:
        parts.append(
            f"{seconds}s"
        )

    return " ".join(parts)


# ============================================================
# GIVEAWAY BUTTON
# ============================================================

class GiveawayView(discord.ui.View):

    def __init__(
        self,
        cog,
        giveaway_id: int
    ):
        super().__init__(
            timeout=None
        )

        self.cog = cog
        self.giveaway_id = giveaway_id

        button = discord.ui.Button(
            label="Enter Giveaway",
            emoji="🎉",
            style=discord.ButtonStyle.primary,
            custom_id=(
                f"giveaway_enter:{giveaway_id}"
            )
        )

        button.callback = self.enter_callback

        self.add_item(button)

    async def enter_callback(
        self,
        interaction: discord.Interaction
    ):
        await self.cog.enter_giveaway(
            interaction,
            self.giveaway_id
        )


# ============================================================
# CONFIRMATION BUTTONS
# ============================================================

class GiveawayConfirmView(
    discord.ui.View
):

    def __init__(
        self,
        cog,
        user_id: int
    ):
        super().__init__(
            timeout=60
        )

        self.cog = cog
        self.user_id = user_id

    @discord.ui.button(
        label="Start Giveaway",
        emoji="🎉",
        style=discord.ButtonStyle.success
    )
    async def confirm(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button
    ):

        if interaction.user.id != self.user_id:
            await interaction.response.send_message(
                "❌ Only the person who created "
                "this giveaway can confirm it.",
                ephemeral=True
            )
            return

        await self.cog.create_giveaway(
            interaction
        )

        self.stop()

    @discord.ui.button(
        label="Cancel",
        emoji="❌",
        style=discord.ButtonStyle.danger
    )
    async def cancel(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button
    ):

        if interaction.user.id != self.user_id:
            await interaction.response.send_message(
                "❌ Only the person who created "
                "this giveaway can cancel it.",
                ephemeral=True
            )
            return

        self.cog.pending_giveaways.pop(
            interaction.user.id,
            None
        )

        await interaction.response.edit_message(
            content="❌ Giveaway creation cancelled.",
            embed=None,
            view=None
        )

        self.stop()


# ============================================================
# GIVEAWAY COG
# ============================================================

class Giveaway(commands.Cog):

    giveaway = app_commands.Group(
        name="giveaway",
        description="Manage APRET MC giveaways."
    )

    def __init__(
        self,
        bot: commands.Bot
    ):
        self.bot = bot

        self.pending_giveaways = {}

        self.initialize_tables()

        self.check_giveaways.start()

    # ========================================================
    # COG UNLOAD
    # ========================================================

    def cog_unload(self):
        self.check_giveaways.cancel()

    # ========================================================
    # DATABASE
    # ========================================================

    def initialize_tables(self):

        connection = get_connection()

        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS giveaways (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id INTEGER NOT NULL,
                channel_id INTEGER NOT NULL,
                message_id INTEGER NOT NULL,
                host_id INTEGER NOT NULL,
                prize TEXT NOT NULL,
                winners INTEGER NOT NULL,
                ends_at INTEGER NOT NULL,
                ended INTEGER NOT NULL DEFAULT 0,
                created_at INTEGER NOT NULL
            )
            """
        )

        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS giveaway_entries (
                giveaway_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                PRIMARY KEY (
                    giveaway_id,
                    user_id
                )
            )
            """
        )

        connection.commit()
        connection.close()

    # ========================================================
    # STAFF CHECK
    # ========================================================

    def is_staff(
        self,
        member: discord.Member
    ) -> bool:

        if member.guild_permissions.administrator:
            return True

        return any(
            role.name == STAFF_ROLE_NAME
            for role in member.roles
        )

    # ========================================================
    # LOGGING
    # ========================================================

    async def send_log(
        self,
        guild: discord.Guild,
        title: str,
        description: str
    ):

        channel = discord.utils.get(
            guild.text_channels,
            name=LOG_CHANNEL_NAME
        )

        if channel is None:
            return

        embed = discord.Embed(
            title=title,
            description=description,
            color=discord.Color.blurple()
        )

        embed.set_footer(
            text="APRET MC • Giveaways"
        )

        try:
            await channel.send(
                embed=embed
            )
        except discord.HTTPException:
            pass

    # ========================================================
    # START GIVEAWAY
    # ========================================================

    @giveaway.command(
        name="start",
        description="Start a new giveaway."
    )
    @app_commands.describe(
        prize="The giveaway prize.",
        duration="Duration such as 30m, 2h or 1d.",
        winners="Number of winners."
    )
    async def giveaway_start(
        self,
        interaction: discord.Interaction,
        prize: str,
        duration: str,
        winners: app_commands.Range[
            int,
            1,
            20
        ]
    ):

        if not isinstance(
            interaction.user,
            discord.Member
        ):
            await interaction.response.send_message(
                "❌ This command can only be used "
                "inside a server.",
                ephemeral=True
            )
            return

        if not self.is_staff(
            interaction.user
        ):
            await interaction.response.send_message(
                "❌ You don't have permission "
                "to start giveaways.",
                ephemeral=True
            )
            return

        seconds = parse_duration(
            duration
        )

        if seconds is None:
            await interaction.response.send_message(
                "❌ Invalid duration.\n\n"
                "Examples:\n"
                "`30s`\n"
                "`10m`\n"
                "`2h`\n"
                "`1d`\n"
                "`1h30m`",
                ephemeral=True
            )
            return

        if seconds < 10:
            await interaction.response.send_message(
                "❌ Giveaway duration must be "
                "at least **10 seconds**.",
                ephemeral=True
            )
            return

        if seconds > 30 * 86400:
            await interaction.response.send_message(
                "❌ Giveaway duration cannot "
                "exceed **30 days**.",
                ephemeral=True
            )
            return

        ends_at = (
            int(time.time())
            + seconds
        )

        self.pending_giveaways[
            interaction.user.id
        ] = {
            "guild_id": interaction.guild.id,
            "channel_id": interaction.channel.id,
            "host_id": interaction.user.id,
            "prize": prize,
            "winners": int(winners),
            "ends_at": ends_at
        }

        embed = discord.Embed(
            title="🎁 Giveaway Preview",
            color=discord.Color.blurple()
        )

        embed.add_field(
            name="🎁 Prize",
            value=prize,
            inline=False
        )

        embed.add_field(
            name="🏆 Winners",
            value=str(winners),
            inline=True
        )

        embed.add_field(
            name="⏱️ Duration",
            value=format_duration(
                seconds
            ),
            inline=True
        )

        embed.add_field(
            name="⏰ Ends",
            value=f"<t:{ends_at}:R>",
            inline=True
        )

        embed.set_footer(
            text="Confirm to start this giveaway."
        )

        await interaction.response.send_message(
            embed=embed,
            view=GiveawayConfirmView(
                self,
                interaction.user.id
            ),
            ephemeral=True
        )

    # ========================================================
    # CREATE GIVEAWAY
    # ========================================================

    async def create_giveaway(
        self,
        interaction: discord.Interaction
    ):

        data = self.pending_giveaways.pop(
            interaction.user.id,
            None
        )

        if data is None:
            await interaction.response.edit_message(
                content=(
                    "❌ Giveaway setup expired. "
                    "Please create it again."
                ),
                embed=None,
                view=None
            )
            return

        channel = interaction.guild.get_channel(
            data["channel_id"]
        )

        if channel is None:
            await interaction.response.edit_message(
                content=(
                    "❌ The giveaway channel "
                    "could not be found."
                ),
                embed=None,
                view=None
            )
            return

        embed = discord.Embed(
            title="🎉 GIVEAWAY",
            description=(
                f"## 🎁 {data['prize']}\n\n"
                f"🏆 **Winners:** "
                f"`{data['winners']}`\n"
                f"⏰ **Ends:** "
                f"<t:{data['ends_at']}:R>\n\n"
                "Click the button below "
                "to enter!"
            ),
            color=discord.Color.blurple()
        )

        embed.set_footer(
            text=(
                f"Hosted by "
                f"{interaction.user.display_name}"
            )
        )

        connection = get_connection()

        cursor = connection.execute(
            """
            INSERT INTO giveaways (
                guild_id,
                channel_id,
                message_id,
                host_id,
                prize,
                winners,
                ends_at,
                ended,
                created_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?)
            """,
            (
                data["guild_id"],
                data["channel_id"],
                0,
                data["host_id"],
                data["prize"],
                data["winners"],
                data["ends_at"],
                int(time.time())
            )
        )

        giveaway_id = cursor.lastrowid

        connection.commit()
        connection.close()

        message = await channel.send(
            embed=embed,
            view=GiveawayView(
                self,
                giveaway_id
            )
        )

        connection = get_connection()

        connection.execute(
            """
            UPDATE giveaways
            SET message_id = ?
            WHERE id = ?
            """,
            (
                message.id,
                giveaway_id
            )
        )

        connection.commit()
        connection.close()

        await interaction.response.edit_message(
            content=(
                f"✅ Giveaway **#{giveaway_id}** "
                f"has been started in "
                f"{channel.mention}!"
            ),
            embed=None,
            view=None
        )

        await self.send_log(
            interaction.guild,
            "🎉 Giveaway Started",
            (
                f"**ID:** `{giveaway_id}`\n"
                f"**Prize:** {data['prize']}\n"
                f"**Winners:** {data['winners']}\n"
                f"**Host:** {interaction.user.mention}\n"
                f"**Channel:** {channel.mention}"
            )
        )

    # ========================================================
    # ENTER GIVEAWAY
    # ========================================================

    async def enter_giveaway(
        self,
        interaction: discord.Interaction,
        giveaway_id: int
    ):

        connection = get_connection()

        giveaway = connection.execute(
            """
            SELECT *
            FROM giveaways
            WHERE id = ?
            """,
            (giveaway_id,)
        ).fetchone()

        if giveaway is None:
            connection.close()

            await interaction.response.send_message(
                "❌ This giveaway doesn't exist.",
                ephemeral=True
            )
            return

        if giveaway["ended"]:
            connection.close()

            await interaction.response.send_message(
                "❌ This giveaway has already ended.",
                ephemeral=True
            )
            return

        if int(time.time()) >= giveaway["ends_at"]:
            connection.close()

            await interaction.response.send_message(
                "❌ This giveaway has already ended.",
                ephemeral=True
            )
            return

        existing = connection.execute(
            """
            SELECT 1
            FROM giveaway_entries
            WHERE giveaway_id = ?
            AND user_id = ?
            """,
            (
                giveaway_id,
                interaction.user.id
            )
        ).fetchone()

        if existing:
            connection.close()

            await interaction.response.send_message(
                "🎉 You're already entered!",
                ephemeral=True
            )
            return

        connection.execute(
            """
            INSERT INTO giveaway_entries (
                giveaway_id,
                user_id
            )
            VALUES (?, ?)
            """,
            (
                giveaway_id,
                interaction.user.id
            )
        )

        connection.commit()
        connection.close()

        await interaction.response.send_message(
            "🎉 **You're entered!** Good luck!",
            ephemeral=True
        )

    # ========================================================
    # CANCEL GIVEAWAY
    # ========================================================

    @giveaway.command(
        name="cancel",
        description="Cancel an active giveaway."
    )
    @app_commands.describe(
        giveaway_id="The giveaway ID."
    )
    async def giveaway_cancel(
        self,
        interaction: discord.Interaction,
        giveaway_id: int
    ):

        if not isinstance(
            interaction.user,
            discord.Member
        ):
            return

        if not self.is_staff(
            interaction.user
        ):
            await interaction.response.send_message(
                "❌ You don't have permission "
                "to cancel giveaways.",
                ephemeral=True
            )
            return

        connection = get_connection()

        giveaway = connection.execute(
            """
            SELECT *
            FROM giveaways
            WHERE id = ?
            AND guild_id = ?
            """,
            (
                giveaway_id,
                interaction.guild.id
            )
        ).fetchone()

        if giveaway is None:
            connection.close()

            await interaction.response.send_message(
                "❌ Giveaway not found.",
                ephemeral=True
            )
            return

        if giveaway["ended"]:
            connection.close()

            await interaction.response.send_message(
                "❌ This giveaway has already ended.",
                ephemeral=True
            )
            return

        connection.execute(
            """
            UPDATE giveaways
            SET ended = 1
            WHERE id = ?
            """,
            (giveaway_id,)
        )

        connection.commit()
        connection.close()

        channel = interaction.guild.get_channel(
            giveaway["channel_id"]
        )

        if channel:
            try:
                message = await channel.fetch_message(
                    giveaway["message_id"]
                )

                embed = discord.Embed(
                    title="❌ GIVEAWAY CANCELLED",
                    description=(
                        f"🎁 **{giveaway['prize']}**\n\n"
                        "This giveaway has been cancelled."
                    ),
                    color=discord.Color.red()
                )

                await message.edit(
                    embed=embed,
                    view=None
                )

            except discord.HTTPException:
                pass

        await interaction.response.send_message(
            f"❌ Giveaway **#{giveaway_id}** cancelled."
        )

        await self.send_log(
            interaction.guild,
            "❌ Giveaway Cancelled",
            (
                f"**ID:** `{giveaway_id}`\n"
                f"**Prize:** {giveaway['prize']}\n"
                f"**Cancelled by:** "
                f"{interaction.user.mention}"
            )
        )

    # ========================================================
    # REROLL
    # ========================================================

    @giveaway.command(
        name="reroll",
        description="Reroll an ended giveaway."
    )
    @app_commands.describe(
        giveaway_id="The giveaway ID."
    )
    async def giveaway_reroll(
        self,
        interaction: discord.Interaction,
        giveaway_id: int
    ):

        if not isinstance(
            interaction.user,
            discord.Member
        ):
            return

        if not self.is_staff(
            interaction.user
        ):
            await interaction.response.send_message(
                "❌ You don't have permission "
                "to reroll giveaways.",
                ephemeral=True
            )
            return

        connection = get_connection()

        giveaway = connection.execute(
            """
            SELECT *
            FROM giveaways
            WHERE id = ?
            AND guild_id = ?
            """,
            (
                giveaway_id,
                interaction.guild.id
            )
        ).fetchone()

        if giveaway is None:
            connection.close()

            await interaction.response.send_message(
                "❌ Giveaway not found.",
                ephemeral=True
            )
            return

        if not giveaway["ended"]:
            connection.close()

            await interaction.response.send_message(
                "❌ This giveaway hasn't ended yet.",
                ephemeral=True
            )
            return

        entries = connection.execute(
            """
            SELECT user_id
            FROM giveaway_entries
            WHERE giveaway_id = ?
            """,
            (giveaway_id,)
        ).fetchall()

        connection.close()

        if not entries:
            await interaction.response.send_message(
                "❌ There are no entries to reroll.",
                ephemeral=True
            )
            return

        users = [
            entry["user_id"]
            for entry in entries
        ]

        winner_count = min(
            giveaway["winners"],
            len(users)
        )

        winners = random.sample(
            users,
            winner_count
        )

        mentions = [
            f"<@{user_id}>"
            for user_id in winners
        ]

        await interaction.response.send_message(
            "🔄 **Giveaway Rerolled!**\n\n"
            f"🎁 **Prize:** "
            f"{giveaway['prize']}\n"
            f"🏆 **New winner(s):** "
            f"{', '.join(mentions)}"
        )

        await self.send_log(
            interaction.guild,
            "🔄 Giveaway Rerolled",
            (
                f"**ID:** `{giveaway_id}`\n"
                f"**Prize:** {giveaway['prize']}\n"
                f"**Rerolled by:** "
                f"{interaction.user.mention}"
            )
        )

    # ========================================================
    # AUTOMATIC END CHECK
    # ========================================================

    @tasks.loop(seconds=5)
    async def check_giveaways(self):

        connection = get_connection()

        giveaways = connection.execute(
            """
            SELECT *
            FROM giveaways
            WHERE ended = 0
            AND ends_at <= ?
            """,
            (int(time.time()),)
        ).fetchall()

        connection.close()

        for giveaway in giveaways:

            try:
                await self.end_giveaway(
                    giveaway["id"]
                )

            except Exception as error:
                print(
                    f"Giveaway #{giveaway['id']} "
                    f"failed to end: {error}"
                )

    @check_giveaways.before_loop
    async def before_check_giveaways(self):
        await self.bot.wait_until_ready()

    # ========================================================
    # END GIVEAWAY
    # ========================================================

    async def end_giveaway(
        self,
        giveaway_id: int
    ):

        connection = get_connection()

        giveaway = connection.execute(
            """
            SELECT *
            FROM giveaways
            WHERE id = ?
            """,
            (giveaway_id,)
        ).fetchone()

        if giveaway is None:
            connection.close()
            return

        if giveaway["ended"]:
            connection.close()
            return

        entries = connection.execute(
            """
            SELECT user_id
            FROM giveaway_entries
            WHERE giveaway_id = ?
            """,
            (giveaway_id,)
        ).fetchall()

        connection.execute(
            """
            UPDATE giveaways
            SET ended = 1
            WHERE id = ?
            """,
            (giveaway_id,)
        )

        connection.commit()
        connection.close()

        guild = self.bot.get_guild(
            giveaway["guild_id"]
        )

        if guild is None:
            return

        channel = guild.get_channel(
            giveaway["channel_id"]
        )

        if channel is None:
            return

        winner_ids = []

        if entries:

            users = [
                entry["user_id"]
                for entry in entries
            ]

            winner_count = min(
                giveaway["winners"],
                len(users)
            )

            winner_ids = random.sample(
                users,
                winner_count
            )

        if winner_ids:

            winner_mentions = [
                f"<@{user_id}>"
                for user_id in winner_ids
            ]

            winner_text = ", ".join(
                winner_mentions
            )

            description = (
                f"🎁 **{giveaway['prize']}**\n\n"
                f"🏆 **Winner(s):** "
                f"{winner_text}\n\n"
                f"🎟️ **Entries:** "
                f"{len(entries)}"
            )

        else:

            winner_text = "No valid entries."

            description = (
                f"🎁 **{giveaway['prize']}**\n\n"
                "😔 Nobody entered this giveaway."
            )

        embed = discord.Embed(
            title="🎉 GIVEAWAY ENDED",
            description=description,
            color=discord.Color.gold()
        )

        embed.set_footer(
            text="APRET MC • Giveaway ended"
        )

        try:

            message = await channel.fetch_message(
                giveaway["message_id"]
            )

            await message.edit(
                embed=embed,
                view=None
            )

        except discord.HTTPException:
            pass

        await channel.send(
            "🎉 **Giveaway Winner(s)!**\n\n"
            f"🎁 **{giveaway['prize']}**\n"
            f"🏆 {winner_text}"
        )

        await self.send_log(
            guild,
            "🏆 Giveaway Ended",
            (
                f"**ID:** `{giveaway_id}`\n"
                f"**Prize:** {giveaway['prize']}\n"
                f"**Entries:** {len(entries)}\n"
                f"**Winner(s):** {winner_text}"
            )
        )

    # ========================================================
    # RESTORE BUTTONS AFTER RESTART
    # ========================================================

    async def restore_giveaways(self):

        connection = get_connection()

        giveaways = connection.execute(
            """
            SELECT *
            FROM giveaways
            WHERE ended = 0
            """
        ).fetchall()

        connection.close()

        for giveaway in giveaways:

            try:

                guild = self.bot.get_guild(
                    giveaway["guild_id"]
                )

                if guild is None:
                    continue

                channel = guild.get_channel(
                    giveaway["channel_id"]
                )

                if channel is None:
                    continue

                await channel.fetch_message(
                    giveaway["message_id"]
                )

                self.bot.add_view(
                    GiveawayView(
                        self,
                        giveaway["id"]
                    ),
                    message_id=giveaway["message_id"]
                )

            except Exception as error:

                print(
                    f"Could not restore giveaway "
                    f"#{giveaway['id']}: {error}"
                )

    async def cog_load(self):
        await self.restore_giveaways()


# ============================================================
# REQUIRED DISCORD.PY EXTENSION SETUP
# ============================================================

async def setup(
    bot: commands.Bot
):
    await bot.add_cog(
        Giveaway(bot)
    )