import discord
from discord import app_commands
from discord.ext import commands

from database.database import get_connection


# =========================================================
# CONFIGURATION
# =========================================================

AUTO_ROLE_NAME = "👤・Member"


class Welcome(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    # =========================================================
    # DATABASE HELPERS
    # =========================================================

    def create_settings(self, guild_id: int):
        connection = get_connection()

        connection.execute(
            """
            INSERT OR IGNORE INTO guild_settings (
                guild_id,
                welcome_channel_id,
                leave_channel_id,
                welcome_enabled,
                leave_enabled
            )
            VALUES (?, NULL, NULL, 0, 0)
            """,
            (guild_id,)
        )

        connection.commit()
        connection.close()

    def get_settings(self, guild_id: int):
        self.create_settings(guild_id)

        connection = get_connection()

        settings = connection.execute(
            """
            SELECT
                guild_id,
                welcome_channel_id,
                leave_channel_id,
                welcome_enabled,
                leave_enabled
            FROM guild_settings
            WHERE guild_id = ?
            """,
            (guild_id,)
        ).fetchone()

        connection.close()

        return settings

    # =========================================================
    # WELCOME MESSAGE
    # =========================================================

    async def send_welcome(self, member: discord.Member):
        settings = self.get_settings(member.guild.id)

        if not settings:
            return

        if not settings["welcome_enabled"]:
            return

        channel_id = settings["welcome_channel_id"]

        if not channel_id:
            return

        channel = member.guild.get_channel(channel_id)

        if channel is None:
            return

        embed = discord.Embed(
            title="👋 Welcome to APRET MC!",
            description=(
                f"Welcome {member.mention}! 🎉\n\n"
                f"You are now a member of **{member.guild.name}**.\n"
                "We hope you enjoy your time here!\n\n"
                "⚔️ Have fun and good luck!"
            ),
            color=discord.Color.blurple()
        )

        embed.set_thumbnail(
            url=member.display_avatar.url
        )

        embed.add_field(
            name="👤 Member",
            value=member.mention,
            inline=True
        )

        embed.add_field(
            name="👥 Members",
            value=str(member.guild.member_count),
            inline=True
        )

        embed.set_footer(
            text="APRET MC • Welcome System"
        )

        try:
            await channel.send(embed=embed)

        except discord.Forbidden:
            print(
                f"[Welcome] Missing permission to send messages in "
                f"#{channel.name} ({channel.id})"
            )

        except discord.HTTPException as error:
            print(
                f"[Welcome] Failed to send welcome message: {error}"
            )

    # =========================================================
    # LEAVE MESSAGE
    # =========================================================

    async def send_leave(self, member: discord.Member):
        settings = self.get_settings(member.guild.id)

        if not settings:
            return

        if not settings["leave_enabled"]:
            return

        channel_id = settings["leave_channel_id"]

        if not channel_id:
            return

        channel = member.guild.get_channel(channel_id)

        if channel is None:
            return

        embed = discord.Embed(
            title="👋 Member Left",
            description=(
                f"**{member.display_name}** has left "
                f"**{member.guild.name}**.\n\n"
                "We hope to see you again someday! 💜"
            ),
            color=discord.Color.red()
        )

        embed.set_thumbnail(
            url=member.display_avatar.url
        )

        member_count = max(
            member.guild.member_count or 1,
            1
        )

        embed.add_field(
            name="👥 Members Remaining",
            value=str(member_count),
            inline=True
        )

        embed.set_footer(
            text="APRET MC • Welcome System"
        )

        try:
            await channel.send(embed=embed)

        except discord.Forbidden:
            print(
                f"[Welcome] Missing permission to send messages in "
                f"#{channel.name} ({channel.id})"
            )

        except discord.HTTPException as error:
            print(
                f"[Welcome] Failed to send leave message: {error}"
            )

    # =========================================================
    # MEMBER JOIN EVENT
    # =========================================================

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):

        # -----------------------------------------------------
        # AUTO ROLE
        # -----------------------------------------------------

        auto_role = discord.utils.get(
            member.guild.roles,
            name=AUTO_ROLE_NAME
        )

        if auto_role is not None:

            try:
                await member.add_roles(
                    auto_role,
                    reason="Automatic member role"
                )

                print(
                    f"[AutoRole] Gave {AUTO_ROLE_NAME} "
                    f"to {member} ({member.id})"
                )

            except discord.Forbidden:
                print(
                    f"[AutoRole] Missing permission to give "
                    f"{AUTO_ROLE_NAME} to {member}."
                )

            except discord.HTTPException as error:
                print(
                    f"[AutoRole] Failed to give role: {error}"
                )

        else:
            print(
                f"[AutoRole] Role '{AUTO_ROLE_NAME}' "
                f"was not found in {member.guild.name}."
            )

        # -----------------------------------------------------
        # WELCOME MESSAGE
        # -----------------------------------------------------

        await self.send_welcome(member)

    # =========================================================
    # MEMBER LEAVE EVENT
    # =========================================================

    @commands.Cog.listener()
    async def on_member_remove(self, member: discord.Member):
        await self.send_leave(member)

    # =========================================================
    # /SETWELCOME
    # =========================================================

    @app_commands.command(
        name="setwelcome",
        description="Set the channel for welcome messages."
    )
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.describe(
        channel="The channel where welcome messages will be sent."
    )
    async def setwelcome(
        self,
        interaction: discord.Interaction,
        channel: discord.TextChannel
    ):

        if interaction.guild is None:
            await interaction.response.send_message(
                "❌ This command can only be used inside a server.",
                ephemeral=True
            )
            return

        self.create_settings(interaction.guild.id)

        connection = get_connection()

        connection.execute(
            """
            UPDATE guild_settings
            SET
                welcome_channel_id = ?,
                welcome_enabled = 1
            WHERE guild_id = ?
            """,
            (channel.id, interaction.guild.id)
        )

        connection.commit()
        connection.close()

        embed = discord.Embed(
            title="✅ Welcome System Enabled",
            description=(
                f"Welcome messages will now be sent in "
                f"{channel.mention}."
            ),
            color=discord.Color.green()
        )

        embed.set_footer(
            text="APRET MC • Welcome System"
        )

        await interaction.response.send_message(
            embed=embed
        )

    # =========================================================
    # /SETLEAVE
    # =========================================================

    @app_commands.command(
        name="setleave",
        description="Set the channel for leave messages."
    )
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.describe(
        channel="The channel where leave messages will be sent."
    )
    async def setleave(
        self,
        interaction: discord.Interaction,
        channel: discord.TextChannel
    ):

        if interaction.guild is None:
            await interaction.response.send_message(
                "❌ This command can only be used inside a server.",
                ephemeral=True
            )
            return

        self.create_settings(interaction.guild.id)

        connection = get_connection()

        connection.execute(
            """
            UPDATE guild_settings
            SET
                leave_channel_id = ?,
                leave_enabled = 1
            WHERE guild_id = ?
            """,
            (channel.id, interaction.guild.id)
        )

        connection.commit()
        connection.close()

        embed = discord.Embed(
            title="✅ Leave System Enabled",
            description=(
                f"Leave messages will now be sent in "
                f"{channel.mention}."
            ),
            color=discord.Color.green()
        )

        embed.set_footer(
            text="APRET MC • Welcome System"
        )

        await interaction.response.send_message(
            embed=embed
        )

    # =========================================================
    # /DISABLEWELCOME
    # =========================================================

    @app_commands.command(
        name="disablewelcome",
        description="Disable automatic welcome messages."
    )
    @app_commands.default_permissions(manage_guild=True)
    async def disablewelcome(
        self,
        interaction: discord.Interaction
    ):

        if interaction.guild is None:
            await interaction.response.send_message(
                "❌ This command can only be used inside a server.",
                ephemeral=True
            )
            return

        self.create_settings(interaction.guild.id)

        connection = get_connection()

        connection.execute(
            """
            UPDATE guild_settings
            SET welcome_enabled = 0
            WHERE guild_id = ?
            """,
            (interaction.guild.id,)
        )

        connection.commit()
        connection.close()

        await interaction.response.send_message(
            "🔴 Automatic welcome messages have been disabled."
        )

    # =========================================================
    # /DISABLELEAVE
    # =========================================================

    @app_commands.command(
        name="disableleave",
        description="Disable automatic leave messages."
    )
    @app_commands.default_permissions(manage_guild=True)
    async def disableleave(
        self,
        interaction: discord.Interaction
    ):

        if interaction.guild is None:
            await interaction.response.send_message(
                "❌ This command can only be used inside a server.",
                ephemeral=True
            )
            return

        self.create_settings(interaction.guild.id)

        connection = get_connection()

        connection.execute(
            """
            UPDATE guild_settings
            SET leave_enabled = 0
            WHERE guild_id = ?
            """,
            (interaction.guild.id,)
        )

        connection.commit()
        connection.close()

        await interaction.response.send_message(
            "🔴 Automatic leave messages have been disabled."
        )

    # =========================================================
    # /WELCOMESETTINGS
    # =========================================================

    @app_commands.command(
        name="welcomesettings",
        description="View the current welcome system settings."
    )
    @app_commands.default_permissions(manage_guild=True)
    async def welcomesettings(
        self,
        interaction: discord.Interaction
    ):

        if interaction.guild is None:
            await interaction.response.send_message(
                "❌ This command can only be used inside a server.",
                ephemeral=True
            )
            return

        settings = self.get_settings(interaction.guild.id)

        # Welcome status
        if settings["welcome_enabled"]:
            welcome_status = "🟢 Enabled"
        else:
            welcome_status = "🔴 Disabled"

        # Welcome channel
        if settings["welcome_channel_id"]:
            welcome_channel = interaction.guild.get_channel(
                settings["welcome_channel_id"]
            )

            if welcome_channel:
                welcome_channel_text = welcome_channel.mention
            else:
                welcome_channel_text = "⚠️ Channel not found"
        else:
            welcome_channel_text = "Not configured"

        # Leave status
        if settings["leave_enabled"]:
            leave_status = "🟢 Enabled"
        else:
            leave_status = "🔴 Disabled"

        # Leave channel
        if settings["leave_channel_id"]:
            leave_channel = interaction.guild.get_channel(
                settings["leave_channel_id"]
            )

            if leave_channel:
                leave_channel_text = leave_channel.mention
            else:
                leave_channel_text = "⚠️ Channel not found"
        else:
            leave_channel_text = "Not configured"

        embed = discord.Embed(
            title="⚙️ APRET Welcome System",
            color=discord.Color.blurple()
        )

        embed.add_field(
            name="👋 Welcome Messages",
            value=(
                f"Status: {welcome_status}\n"
                f"Channel: {welcome_channel_text}"
            ),
            inline=False
        )

        embed.add_field(
            name="🚪 Leave Messages",
            value=(
                f"Status: {leave_status}\n"
                f"Channel: {leave_channel_text}"
            ),
            inline=False
        )

        embed.add_field(
            name="🎭 Auto Role",
            value=f"`{AUTO_ROLE_NAME}`",
            inline=False
        )

        embed.set_footer(
            text="APRET MC • Welcome System"
        )

        await interaction.response.send_message(
            embed=embed,
            ephemeral=True
        )

    # =========================================================
    # /WELCOMETEST
    # =========================================================

    @app_commands.command(
        name="welcometest",
        description="Send a test welcome message."
    )
    @app_commands.default_permissions(manage_guild=True)
    async def welcometest(
        self,
        interaction: discord.Interaction
    ):

        if interaction.guild is None:
            await interaction.response.send_message(
                "❌ This command can only be used inside a server.",
                ephemeral=True
            )
            return

        settings = self.get_settings(interaction.guild.id)

        if not settings["welcome_enabled"]:
            await interaction.response.send_message(
                "❌ Welcome messages are currently disabled.\n"
                "Use `/setwelcome` first.",
                ephemeral=True
            )
            return

        channel_id = settings["welcome_channel_id"]

        if not channel_id:
            await interaction.response.send_message(
                "❌ No welcome channel has been configured.",
                ephemeral=True
            )
            return

        channel = interaction.guild.get_channel(channel_id)

        if channel is None:
            await interaction.response.send_message(
                "❌ The configured welcome channel no longer exists.",
                ephemeral=True
            )
            return

        embed = discord.Embed(
            title="👋 Welcome to APRET MC!",
            description=(
                f"Welcome {interaction.user.mention}! 🎉\n\n"
                f"You are now a member of **{interaction.guild.name}**.\n"
                "We hope you enjoy your time here!\n\n"
                "🧪 **This is a test welcome message.**"
            ),
            color=discord.Color.blurple()
        )

        embed.set_thumbnail(
            url=interaction.user.display_avatar.url
        )

        embed.add_field(
            name="👤 Member",
            value=interaction.user.mention,
            inline=True
        )

        embed.set_footer(
            text="APRET MC • Welcome System Test"
        )

        try:
            await channel.send(embed=embed)

            await interaction.response.send_message(
                f"✅ Test welcome message sent to "
                f"{channel.mention}.",
                ephemeral=True
            )

        except discord.Forbidden:
            await interaction.response.send_message(
                "❌ I don't have permission to send messages "
                "in that channel.",
                ephemeral=True
            )

        except discord.HTTPException:
            await interaction.response.send_message(
                "❌ Discord rejected the test message.",
                ephemeral=True
            )

    # =========================================================
    # /LEAVETEST
    # =========================================================

    @app_commands.command(
        name="leavetest",
        description="Send a test leave message."
    )
    @app_commands.default_permissions(manage_guild=True)
    async def leavetest(
        self,
        interaction: discord.Interaction
    ):

        if interaction.guild is None:
            await interaction.response.send_message(
                "❌ This command can only be used inside a server.",
                ephemeral=True
            )
            return

        settings = self.get_settings(interaction.guild.id)

        if not settings["leave_enabled"]:
            await interaction.response.send_message(
                "❌ Leave messages are currently disabled.\n"
                "Use `/setleave` first.",
                ephemeral=True
            )
            return

        channel_id = settings["leave_channel_id"]

        if not channel_id:
            await interaction.response.send_message(
                "❌ No leave channel has been configured.",
                ephemeral=True
            )
            return

        channel = interaction.guild.get_channel(channel_id)

        if channel is None:
            await interaction.response.send_message(
                "❌ The configured leave channel no longer exists.",
                ephemeral=True
            )
            return

        embed = discord.Embed(
            title="👋 Member Left",
            description=(
                f"**{interaction.user.display_name}** has left "
                f"**{interaction.guild.name}**.\n\n"
                "🧪 **This is a test leave message.**"
            ),
            color=discord.Color.red()
        )

        embed.set_thumbnail(
            url=interaction.user.display_avatar.url
        )

        embed.set_footer(
            text="APRET MC • Welcome System Test"
        )

        try:
            await channel.send(embed=embed)

            await interaction.response.send_message(
                f"✅ Test leave message sent to "
                f"{channel.mention}.",
                ephemeral=True
            )

        except discord.Forbidden:
            await interaction.response.send_message(
                "❌ I don't have permission to send messages "
                "in that channel.",
                ephemeral=True
            )

        except discord.HTTPException:
            await interaction.response.send_message(
                "❌ Discord rejected the test message.",
                ephemeral=True
            )


# =============================================================
# COG SETUP
# =============================================================

async def setup(bot: commands.Bot):
    await bot.add_cog(Welcome(bot))